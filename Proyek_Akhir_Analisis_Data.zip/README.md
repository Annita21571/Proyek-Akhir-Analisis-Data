**Setup Environment - Anaconda**
conda create -n main-ds python=3.9
conda activate main-ds
pip install -r requirements.txt

**Setup Environment - Shell/Terminal**
pip install -r requirements.txt

**Run Steamlit App**
streamlit run dashboard.py
